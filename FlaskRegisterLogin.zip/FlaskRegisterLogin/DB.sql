CREATE DATABASE registrazione_db;

USE registrazione_db;

CREATE TABLE utenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cognome VARCHAR(100),
    eta INT,
    codice_fiscale VARCHAR(20),
    data_nascita DATE,
    numero_telefono VARCHAR(15)
);

# app.py

from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

# Configura il database
mysql = MySQL(app)

@app.route("/", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        # Prendi i dati dal form
        nome = request.form['nome']
        cognome = request.form['cognome']
        eta = request.form['eta']
        codice_fiscale = request.form['codice_fiscale']
        data_nascita = request.form['data_nascita']
        numero_telefono = request.form['numero_telefono']
        
        # Crea una query per inserire i dati nel database
        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO utenti (nome, cognome, eta, codice_fiscale, data_nascita, numero_telefono)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (nome, cognome, eta, codice_fiscale, data_nascita, numero_telefono))
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('register'))  # Dopo aver registrato, ritorna alla pagina

    return render_template('register.html')


if __name__ == "__main__":
    app.run(debug=True)

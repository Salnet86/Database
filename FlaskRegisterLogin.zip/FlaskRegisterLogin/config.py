# config.py

import os

class Config:
    SECRET_KEY = os.urandom(24)  # Chiave segreta per la sessione (può essere cambiata)
    MYSQL_HOST = 'localhost'  # Cambia con il tuo host MySQL
    MYSQL_USER = 'root'  # Cambia con il tuo username MySQL
    MYSQL_PASSWORD = 'password'  # Cambia con la tua password MySQL
    MYSQL_DB = 'registrazione_db'  # Nome del database

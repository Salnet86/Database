from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Un dizionario semplice per l'autenticazione (può essere esteso con un database)
utenti = {
    "admin": "password123",  # coppia username:password
}

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    # Verifica delle credenziali
    if username in utenti and utenti[username] == password:
        return f"Benvenuto {username}!"
    else:
        return "Credenziali errate, riprova."

if __name__ == '__main__':
    app.run(debug=True)

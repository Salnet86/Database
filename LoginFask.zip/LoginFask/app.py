from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from config import Config

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Cambia con una chiave segreta sicura
app.config.from_object(Config)

# Connessione al database
def get_db_connection():
    conn = mysql.connector.connect(
        host=app.config['MYSQL_HOST'],
        user=app.config['MYSQL_USER'],
        password=app.config['MYSQL_PASSWORD'],
        database=app.config['MYSQL_DB']
    )
    return conn

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Query per verificare se l'utente esiste nel database
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()

        cursor.close()
        conn.close()

        if user:
            flash('Login effettuato con successo!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Credenziali non valide', 'danger')
            return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)

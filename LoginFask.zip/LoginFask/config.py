import os

class Config:
    MYSQL_HOST = 'localhost'  # Modifica con il tuo host MySQL
    MYSQL_USER = 'root'  # Modifica con il tuo utente
    MYSQL_PASSWORD = 'password'  # Modifica con la tua password
    MYSQL_DB = 'nome_database'  # Modifica con il tuo nome database

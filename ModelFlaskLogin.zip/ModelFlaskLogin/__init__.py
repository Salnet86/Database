from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# Inizializza app e database
db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    # Inizializza il database
    db.init_app(app)
    login_manager.init_app(app)

    # Importa le route
    from . import routes
    app.register_blueprint(routes.bp)

    return app

import os

class Config:
    SECRET_KEY = os.urandom(24)  # Per la sicurezza del login
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://username:password@localhost/db_name'

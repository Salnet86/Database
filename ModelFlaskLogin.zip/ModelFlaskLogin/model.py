from . import db
from flask_login import UserMixin

# Modello per l'utente
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    cognome = db.Column(db.String(100), nullable=False)
    data_nascita = db.Column(db.Date, nullable=False)
    codice_fiscale = db.Column(db.String(16), unique=True, nullable=False)
    telefono = db.Column(db.String(15), nullable=False)
    indirizzo = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f'<User {self.nome} {self.cognome}>'

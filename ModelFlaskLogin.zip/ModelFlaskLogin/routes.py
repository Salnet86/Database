from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, login_required, logout_user, current_user
from . import db
from .model import User
from werkzeug.security import generate_password_hash, check_password_hash

bp = Blueprint('routes', __name__)

# Route per la homepage (accessibile solo se loggato)
@bp.route('/')
@login_required
def home():
    return render_template('home.html')

# Route per il login
@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('routes.home'))
        else:
            flash('Email o password errati')
    return render_template('login.html')

# Route per la registrazione
@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nome = request.form['nome']
        cognome = request.form['cognome']
        data_nascita = request.form['data_nascita']
        codice_fiscale = request.form['codice_fiscale']
        telefono = request.form['telefono']
        indirizzo = request.form['indirizzo']
        email = request.form['email']
        password = request.form['password']
        
        hashed_password = generate_password_hash(password, method='sha256')
        
        user = User(nome=nome, cognome=cognome, data_nascita=data_nascita, 
                    codice_fiscale=codice_fiscale, telefono=telefono, 
                    indirizzo=indirizzo, email=email, password=hashed_password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registrazione avvenuta con successo!')
        return redirect(url_for('routes.login'))
    
    return render_template('register.html')

# Route per il logout
@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('routes.login'))

from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
import hashlib

# Configurazione di Flask
app = Flask(__name__)

# Configurazione del database MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  # Cambia con il tuo utente
app.config['MYSQL_PASSWORD'] = ''  # La tua password MySQL
app.config['MYSQL_DB'] = 'flask_db'

mysql = MySQL(app)

# Funzione per registrare un nuovo utente
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        nome = request.form['nome']
        cognome = request.form['cognome']

        # Criptare la password per sicurezza
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Connessione al database e inserimento dati
        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO utenti (email, password, nome, cognome) VALUES (%s, %s, %s, %s)", 
                        (email, hashed_password, nome, cognome))
            mysql.connection.commit()
            cur.close()
            return redirect(url_for('login'))  # Reindirizza alla pagina di login dopo la registrazione
        except Exception as e:
            cur.close()
            return f"Errore: {str(e)}"
    
    return render_template('register.html')

# Funzione per il login (opzionale, puoi aggiungerla per testare la registrazione)
@app.route('/login', methods=['GET', 'POST'])
def login():
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)


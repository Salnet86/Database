nome = "salvatore"



if  nome:
    print("Egiusto")
else:
    print("Non e giusto")

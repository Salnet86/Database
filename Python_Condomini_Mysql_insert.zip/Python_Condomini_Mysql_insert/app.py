from flask import Flask, render_template, request, redirect, url_for
import db

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/inserisci', methods=['GET', 'POST'])
def inserisci_ammiratore():
    if request.method == 'POST':
        nome = request.form['nome']
        cognome = request.form['cognome']
        tipo_lavoro = request.form['tipo_lavoro']
        tasse_pagate = float(request.form['tasse_pagate'])
        assemblea_data_ora = request.form['assemblea_data_ora']
        db.inserisci_ammiratore(nome, cognome, tipo_lavoro, tasse_pagate, assemblea_data_ora)
        return redirect(url_for('home'))
    return render_template('inserimento.html')

@app.route('/inserisci_utente', methods=['GET', 'POST'])
def inserisci_utente():
    if request.method == 'POST':
        nome = request.form['nome']
        cognome = request.form['cognome']
        codice_fiscale = request.form['codice_fiscale']
        numero_telefono = request.form['numero_telefono']
        email = request.form['email']
        db.inserisci_utente(nome, cognome, codice_fiscale, numero_telefono, email)
        return redirect(url_for('home'))
    return render_template('inserimento_utente.html')

@app.route('/visualizza_ammiratori')
def visualizza_ammiratori():
    ammiratori = db.ottieni_ammiratori()
    return render_template('visualizza.html', ammiratori=ammiratori, tipo='Ammiratori')

@app.route('/visualizza_utenti')
def visualizza_utenti():
    utenti = db.ottieni_utenti()
    return render_template('visualizza.html', utenti=utenti, tipo='Utenti')

if __name__ == '__main__':
    app.run(debug=True)

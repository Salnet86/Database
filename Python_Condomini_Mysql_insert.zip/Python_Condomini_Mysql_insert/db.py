import pymysql.cursors

# Funzione per ottenere la connessione al database MySQL
def get_db_connection():
    connection = pymysql.connect(
        host='localhost',  # L'indirizzo del tuo server MySQL
        user='tuo_utente',  # Il tuo nome utente MySQL
        password='tua_password',  # La tua password MySQL
        database='nome_database',  # Il nome del tuo database
        cursorclass=pymysql.cursors.DictCursor  # Per ottenere i risultati come dizionari
    )
    return connection

# Funzione per inserire un ammiratore
def inserisci_ammiratore(nome, cognome, tipo_lavoro, tasse_pagate, assemblea_data_ora):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO ammiratori (nome, cognome, tipo_lavoro, tasse_pagate, assemblea_data_ora)
        VALUES (%s, %s, %s, %s, %s)
    """, (nome, cognome, tipo_lavoro, tasse_pagate, assemblea_data_ora))
    conn.commit()
    cursor.close()
    conn.close()

# Funzione per inserire un utente
def inserisci_utente(nome, cognome, codice_fiscale, numero_telefono, email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO utenti (nome, cognome, codice_fiscale, numero_telefono, email)
        VALUES (%s, %s, %s, %s, %s)
    """, (nome, cognome, codice_fiscale, numero_telefono, email))
    conn.commit()
    cursor.close()
    conn.close()

# Funzione per ottenere gli ammiratori
def ottieni_ammiratori():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ammiratori")
    ammiratori = cursor.fetchall()
    cursor.close()
    conn.close()
    return ammiratori

# Funzione per ottenere gli utenti
def ottieni_utenti():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM utenti")
    utenti = cursor.fetchall()
    cursor.close()
    conn.close()
    return utenti

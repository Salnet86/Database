import pandas as pd
import mysql.connector
from mysql.connector import Error
import json

# Funzione per leggere il file JSON e convertirlo in un DataFrame
def json_to_dataframe(file_path):
    with open(file_path, 'r') as file:
        # Carica i dati JSON
        data = json.load(file)
    
    # Crea il DataFrame con i dati JSON
    df = pd.json_normalize(data)
    return df

# Funzione per inserire i dati nel database MySQL
def insert_data_to_mysql(df, db_config):
    try:
        # Creare la connessione al database MySQL
        connection = mysql.connector.connect(
            host=db_config['host'],
            database=db_config['database'],
            user=db_config['user'],
            password=db_config['password']
        )

        if connection.is_connected():
            print("Connessione al database riuscita!")

            cursor = connection.cursor()

            # Creare una tabella (se non esiste già)
            create_table_query = """
            CREATE TABLE IF NOT EXISTS materiali_chimici (
                id VARCHAR(10) PRIMARY KEY,
                name VARCHAR(100),
                chemical_formula VARCHAR(50),
                molecular_weight FLOAT,
                melting_point VARCHAR(50),
                boiling_point VARCHAR(50),
                density VARCHAR(50)
            );
            """
            cursor.execute(create_table_query)
            print("Tabella 'materiali_chimici' creata!")

            # Inserire i dati nel database
            insert_query = """
            INSERT INTO materiali_chimici (id, name, chemical_formula, molecular_weight, melting_point, boiling_point, density)
            VALUES (%s, %s, %s, %s, %s, %s, %s);
            """
            
            # Iterare sulle righe del DataFrame e inserire nel database
            for index, row in df.iterrows():
                cursor.execute(insert_query, tuple(row))
            
            # Completare l'inserimento dei dati
            connection.commit()
            print(f"{cursor.rowcount} righe inserite nel database.")

    except Error as e:
        print("Errore durante la connessione o inserimento nel database:", e)
    finally:
        # Chiudere la connessione al database
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("Connessione al database chiusa.")

# Configurazione del database
db_config = {
    'host': 'localhost',     # Indirizzo del tuo server MySQL
    'database': 'nome_del_tuo_database',  # Nome del database MySQL
    'user': 'nome_utente',   # Nome utente MySQL
    'password': 'tua_password'  # La tua password MySQL
}

# Percorso del file JSON
file_path = 'materiali_chimici.json'

# Leggi il file JSON e convertilo in un DataFrame
df = json_to_dataframe(file_path)

# Inserisci i dati nel database MySQL
insert_data_to_mysql(df, db_config)

import pandas as pd
import json

# Funzione per leggere il file JSON e convertirlo in un DataFrame
def json_to_dataframe(file_path):
    with open(file_path, 'r') as file:
        # Carica i dati JSON
        data = json.load(file)
    
    # Crea il DataFrame con i dati JSON
    df = pd.json_normalize(data)
    return df

# Percorso del file JSON
file_path = 'materiali_chimici.json'

# Leggi il file e convertilo in DataFrame
df = json_to_dataframe(file_path)

# Visualizza il DataFrame
print(df)

import pandas as pd

# Caricare il file JSON
df = pd.read_json('materiali_chimici.json')

# Mostrare le prime righe per verificare il caricamento
print(df.head())

# 1. Selezionare solo il nome e la formula chimica dei materiali
print("\nNome e formula chimica di ogni materiale:")
print(df[['name', 'chemical_formula']])

# 2. Trovare i materiali con un peso molecolare superiore a 50
df_alto_peso = df[df['molecular_weight'] > 50]
print("\nMateriali con peso molecolare superiore a 50:")
print(df_alto_peso[['name', 'molecular_weight']])

# 3. Selezionare i materiali con una densità compresa tra 1 e 5 g/cm³
df_densita_intervallo = df[(df['density'].str.replace(' g/cm³', '').astype(float) >= 1) & (df['density'].str.replace(' g/cm³', '').astype(float) <= 5)]
print("\nMateriali con densità tra 1 e 5 g/cm³:")
print(df_densita_intervallo[['name', 'density']])

# 4. Ordinare i materiali per punto di ebollizione in ordine decrescente
df['boiling_point_numeric'] = df['boiling_point'].str.replace(' °C', '').astype(float)
df_ordinato_ebollizione = df.sort_values(by='boiling_point_numeric', ascending=False)
print("\nMateriali ordinati per punto di ebollizione decrescente:")
print(df_ordinato_ebollizione[['name', 'boiling_point']])

# 5. Trovare tutti i gas a temperatura ambiente (punto di fusione inferiore a 25°C)
df['melting_point_numeric'] = df['melting_point'].str.replace(' °C', '').astype(float)
df_gas = df[df['melting_point_numeric'] < 25]
print("\nMateriali gassosi a temperatura ambiente:")
print(df_gas[['name', 'melting_point']])

# 6. Trovare i materiali con formula chimica contenente ossigeno ('O')
df_ossigeno = df[df['chemical_formula'].str.contains('O')]
print("\nMateriali contenenti ossigeno:")
print(df_ossigeno[['name', 'chemical_formula']])

# 7. Contare quanti materiali sono solidi a temperatura ambiente (punto di fusione superiore a 25°C)
solidi_count = len(df[df['melting_point_numeric'] > 25])
print("\nNumero di materiali solidi a temperatura ambiente:", solidi_count)

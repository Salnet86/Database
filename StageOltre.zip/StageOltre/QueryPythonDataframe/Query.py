import pandas as pd

# Caricare il file JSON
df = pd.read_json('materiali_chimici.json')

# Mostrare le prime righe per verificare il caricamento
print(df.head())

# 1. Trovare i materiali con densità superiore a 5 g/cm³
print("\nMateriali con densità > 5 g/cm³:")
print(df[df['density'].str.replace(' g/cm³', '').astype(float) > 5])

# 2. Trovare il materiale con il punto di fusione più basso
df['melting_point_numeric'] = df['melting_point'].str.replace(' °C', '').astype(float)
print("\nMateriale con il punto di fusione più basso:")
print(df.loc[df['melting_point_numeric'].idxmin()])

# 3. Filtrare per un materiale specifico (esempio: Acido Solforico)
materiale = 'Acido Solforico'
print(f"\nDati per {materiale}:")
print(df[df['name'] == materiale])

# 4. Ordinare i materiali per peso molecolare
print("\nMateriali ordinati per peso molecolare:")
print(df.sort_values('molecular_weight'))

# 5. Trovare materiali con punto di ebollizione sopra 1500°C
df['boiling_point_numeric'] = df['boiling_point'].str.replace(' °C', '').astype(float)
print("\nMateriali con punto di ebollizione sopra 1500°C:")
print(df[df['boiling_point_numeric'] > 1500])

# 6. Contare quanti materiali hanno una densità inferiore a 1
densita_bassa = df[df['density'].str.replace(' g/cm³', '').astype(float) < 1]
print("\nNumero di materiali con densità < 1 g/cm³:", len(densita_bassa))

# 7. Raggruppare i materiali per stato fisico approssimato
def stato_fisico(row):
    if row['melting_point_numeric'] < 0:
        return 'Gas'
    elif row['melting_point_numeric'] < 100:
        return 'Liquido'
    else:
        return 'Solido'

df['stato_fisico'] = df.apply(stato_fisico, axis=1)
print("\nMateriali raggruppati per stato fisico approssimato:")
print(df.groupby('stato_fisico').size())

from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField, SubmitField
from wtforms.validators import DataRequired
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Configurazione del database MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'password'
app.config['MYSQL_DB'] = 'user_data'

mysql = MySQL(app)

# Form per la registrazione dell'utente
class RegistrationForm(FlaskForm):
    nome = StringField('Nome', validators=[DataRequired()])
    cognome = StringField('Cognome', validators=[DataRequired()])
    data_di_nascita = DateField('Data di Nascita', format='%Y-%m-%d', validators=[DataRequired()])
    eta = IntegerField('Età', validators=[DataRequired()])
    codice_fiscale = StringField('Codice Fiscale', validators=[DataRequired()])
    indirizzo = StringField('Indirizzo', validators=[DataRequired()])
    numero_telefono = StringField('Numero di Telefono', validators=[DataRequired()])
    carta_identita_numero = StringField('Numero Carta di Identità', validators=[DataRequired()])
    submit = SubmitField('Registrati')

# Pagina di login (per semplicità, una pagina di login base)
@app.route('/')
def login():
    return render_template('login.html')

# Pagina di registrazione
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        nome = form.nome.data
        cognome = form.cognome.data
        data_di_nascita = form.data_di_nascita.data
        eta = form.eta.data
        codice_fiscale = form.codice_fiscale.data
        indirizzo = form.indirizzo.data
        numero_telefono = form.numero_telefono.data
        carta_identita_numero = form.carta_identita_numero.data

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO users (nome, cognome, data_di_nascita, eta, codice_fiscale, indirizzo, numero_telefono, carta_identita_numero)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (nome, cognome, data_di_nascita, eta, codice_fiscale, indirizzo, numero_telefono, carta_identita_numero))
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('login'))

    return render_template('registration.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)

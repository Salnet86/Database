CREATE DATABASE user_data;

USE user_data;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cognome VARCHAR(100),
    data_di_nascita DATE,
    eta INT,
    codice_fiscale VARCHAR(16),
    indirizzo VARCHAR(255),
    numero_telefono VARCHAR(15),
    carta_identita_numero VARCHAR(20)
);
